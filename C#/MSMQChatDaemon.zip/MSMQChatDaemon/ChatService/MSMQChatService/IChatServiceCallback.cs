﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace MSMQChatService
{
    public interface IChatServiceCallback
    {
        [OperationContract(IsOneWay=true)]
        void JoinCallBack(string userName); // user join

        [OperationContract(IsOneWay=true)]
        void ReceiveGroupChatMsgCallback(string sender, string message);  //receive group chating message

        [OperationContract(IsOneWay=true)]
        void ReceiveSingleChatMsgCallback(string sender, string message); //receive single chating message

        [OperationContract(IsOneWay=true)]
        void LeaveMeetingCallBack(string userName);  //user leave
    }
}
