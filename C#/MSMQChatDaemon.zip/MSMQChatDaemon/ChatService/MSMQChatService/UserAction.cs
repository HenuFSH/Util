﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MSMQChatService
{
    public enum UserAction
    {
        JoinMeeting=0,
        GroupChat=1,
        SingleChat=2,
        LeaveMeeting=3
    }
}
