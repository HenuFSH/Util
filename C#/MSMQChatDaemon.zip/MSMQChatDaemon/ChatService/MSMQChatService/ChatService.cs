﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace MSMQChatService
{
    //全局委托
    public delegate void ChatDelegate(object sender, MessageEntity msg); 

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession,ConcurrencyMode=ConcurrencyMode.Multiple)]
   public  class ChatService:IChatService
   {
        //事件
        public static event ChatDelegate ChatEvent; 
        //回调接口
        private IChatServiceCallback chatCallback = null;
        //同步锁定对象
        private object lockSync = new object();
        //登录用户和注册的委托事件的键值对. 每一个用户名都有对应的委托事件,委托事件可以触发回调方法
        private static Dictionary<string, ChatDelegate> chatDict = new Dictionary<string, ChatDelegate>(1024);
        //当前登录用户名
        private string joiner;  

        //回调函数
        private void MessageToSendToClientSide(object sender, MessageEntity msg)
        {
            try
            {
                switch(msg.UAction)
                {
                        //登录
                    case UserAction.JoinMeeting:
                        chatCallback.JoinCallBack(msg.Sender);
                        break;
                        //群聊
                    case UserAction.GroupChat:
                        chatCallback.ReceiveGroupChatMsgCallback(msg.Sender, msg.MessageBody);
                        break;
                        //单聊
                    case UserAction.SingleChat:
                        chatCallback.ReceiveSingleChatMsgCallback(msg.Sender, msg.MessageBody);
                        break;
                        //离开
                    case UserAction.LeaveMeeting:
                        chatCallback.LeaveMeetingCallBack(msg.Sender);
                        break;
                    default: break;
                }
            }
            catch
            {
                LeaveMeeting();
            }
        }

        //触发委托链上面的事件
        private void HandleMessageInDelegatePool(MessageEntity msg)
        {
            if (ChatEvent != null)
            {
                foreach (ChatDelegate chatDelegate in ChatEvent.GetInvocationList())
                {
                    //触发事件,实际触发的是回调函数,也就是服务端会通过触发chatDelegate来将不同的登录用户的信息给返回给客户端,这样我们就可以知道谁加入了会议,谁说了什么话了.
                    chatDelegate.BeginInvoke(this, msg, new AsyncCallback(new Action<IAsyncResult>((iar) =>
                    {
                        ChatDelegate dele = null;
                        try
                        {
                            dele = (ChatDelegate)iar.AsyncState;
                            dele.EndInvoke(iar);
                        }
                        catch
                        {
                            ChatEvent -= dele;
                        }
                    })), chatDelegate);
                }
            }
        }

       #region Methods in IChatService
        //加入会议
       public string[] JoinMeeting(string name)
        {
            bool flag = true;
            bool userIncluded = false;
            if (String.IsNullOrEmpty(name))
                flag = false;

            if (flag)
            {
                lock (lockSync)
                {
                    if (!chatDict.ContainsKey(name))
                    {
                        joiner = name;
                        //这里保存的是chatEvent委托并且触发的事件
                        chatDict.Add(name, MessageToSendToClientSide);
                        userIncluded = true;
                    }
                }
            }

           //perform callback operation to client side so that the users in the chat session will have their chat user list refreshed.
            if (userIncluded)
            {
                //实例
                chatCallback = OperationContext.Current.GetCallbackChannel<IChatServiceCallback>();
                MessageEntity entity = new MessageEntity();
                entity.Sender = name;
                entity.UAction = UserAction.JoinMeeting;
                //用户一旦登录,首先会发送自己上线的消息给其他人
                HandleMessageInDelegatePool(entity);
                //之后用户会订阅其他相关操作: 群聊,单聊,退出 
                ChatEvent += MessageToSendToClientSide;

                //copy user list and return.
                string[] userList = new string[chatDict.Count];
                lock (lockSync)
                    chatDict.Keys.CopyTo(userList, 0);
                return userList;
            }
            else
                return null;
        }
        //群聊
        public void GroupChat(string message)
        {
            //信息实体
            MessageEntity entity = new MessageEntity();
            entity.MessageBody = message;
            entity.Sender = joiner;
            entity.UAction = UserAction.GroupChat;
            //遍历委托链,触发回调函数,将内容发给所有在线的人
            HandleMessageInDelegatePool(entity);
        }
        //单聊
        public void SingleChat(string toWho, string message)
        {
            //信息实体
            MessageEntity entity = new MessageEntity();
            entity.MessageBody = message;
            entity.UAction = UserAction.SingleChat;
            entity.Sender = joiner;

            ChatDelegate dele = null;
            ChatDelegate myChatDele=null;
            try
            {
                lock (lockSync)
                {
                    //得到待触发的事件
                    dele = chatDict[toWho];
                }
            }
            catch(KeyNotFoundException ex)
            {
                throw new KeyNotFoundException("Can't find user, pls check:" + ex.Message);
            }

            try
            {
                //触发
                dele.BeginInvoke(this, entity, new AsyncCallback(new Action<IAsyncResult>(iar =>
                {
                    myChatDele = (ChatDelegate)iar.AsyncState;
                    myChatDele.EndInvoke(iar);
                })), dele);
            }
            catch
            {
                ChatEvent -= myChatDele;
            }
        }

        //离开会议
        public void LeaveMeeting()
        {
            lock (lockSync)
            {
                chatDict.Remove(joiner);
            }
            //将委托从委托链中移除,那么之后此用户将不会接收到其他人发送的信息
            ChatEvent -= MessageToSendToClientSide;
            MessageEntity entity = new MessageEntity();
            entity.UAction = UserAction.LeaveMeeting;
            entity.Sender = joiner;
            joiner = null;
            //发送给所有在线的人,通知下线
            HandleMessageInDelegatePool(entity);
        }
       #endregion
   }
}
