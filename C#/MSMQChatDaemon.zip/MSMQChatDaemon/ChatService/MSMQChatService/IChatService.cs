﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace MSMQChatService
{
    [ServiceContract(SessionMode = SessionMode.Required, CallbackContract = typeof(IChatServiceCallback))]
    public interface IChatService
    {
        [OperationContract(IsOneWay = false, IsInitiating = true, IsTerminating = false, Name = "JoinMeeting")]
        string[] JoinMeeting(string name); //Join the meeting

        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = false,Name="GroupChat")]
        void GroupChat(string message);   //Group Chating in the meeting

        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = false,Name="SingleChat")]
        void SingleChat(string toWho, string message); // Single chating to someone in the meeting

        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = true,Name="LeaveMeeting")]
        void LeaveMeeting();  //Leave the meeting room
    }
}
