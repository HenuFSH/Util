﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceModel;
using System.Threading;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Trestan;

namespace MSMQChatClient
{

    public partial class MainFrm : Form, IChatServiceCallback
    {
        public MainFrm()
        {
            InitializeComponent();
            SetMainTreadState();
            SetUserLoginState();
        }

        private const int WM_VSCROLL = 0x115;
        private const int SB_BOTTOM = 7;

        private LoginFrm loginFrm = null;
        private ChatServiceClient chatClient = null;
        
        private string nickName = string.Empty;
        private bool emotionFlag = false;
        
        //用以设定主窗体的透明度和任务栏状态
        private void SetMainTreadState()
        {
            this.Opacity = 0;
            this.ShowInTaskbar = false;
        }

        private void ResetMainThreadState()
        {
            this.Opacity = 100;
            this.ShowInTaskbar = true;
            this.BringToFront();
        }

        //用于用户登录
        private void SetUserLoginState()
        {
            if (loginFrm == null || loginFrm.IsDisposed == true)
            {
                loginFrm = new LoginFrm();
                loginFrm.UserLoginEvent += (nickName) =>
                {

                    InstanceContext baseContext = new InstanceContext(this);
                    //创建服务对象的代理实例
                    chatClient = new ChatServiceClient(baseContext);

                    //异步方式处理用户加入信息
                    chatClient.BeginJoinMeeting(nickName, new AsyncCallback(iar =>
                    {
                        string[] userList = null;
                        try
                        {
                            //异步结束,返回用户列表
                            userList = chatClient.EndJoinMeeting(iar);
                        }
                        catch
                        {
                            loginFrm.ShowStatus("Can't connect server...");
                            ExitChatRoom();
                            return;
                        }

                        if (userList == null)
                        {
                            loginFrm.ShowStatus("Duplicate user nick name , can't login...");
                            ExitChatRoom();
                            return;
                        }
                        else
                        {
                            loginFrm.Invoke(new Action(() => { loginFrm.ShowStatus("Login Successfully..."); }));
                        }

                        Thread.Sleep(1000);
                        //关闭登录窗体
                        loginFrm.Invoke(new Action(() => { loginFrm.Close(); }));

                        //重设主窗体的各种状态
                        this.Invoke(new Action(() =>
                        {
                            this.nickName = nickName;
                            ResetMainThreadState();
                            myStatus.Invoke(new Action(() => { statusLabel.Text = string.Format("User {0} has joined successfully!", nickName); }));
                            foreach (string name in userList)
                                SetUserLoginUI(name);
                            NotificationLog("You joined at " + DateTime.Now.ToString() + " with  name (" + nickName + ")");
                        }));
                    }), null);
                };
            }
            loginFrm.Show();
        }

        //用户退出
        private void ExitChatRoom()
        {
            try
            {
                chatClient.LeaveMeeting();
            }
            catch { }
            finally
            {
                DisposeSession();
            }
        }

        //销毁对象
        private void DisposeSession()
        {
            if (chatClient != null)
            {
                chatClient.Abort();
                chatClient.Close();
                chatClient = null;
            }
        }

        #region CallBack回调方法

        //加入会议,这里可以将登录的用户加入到列表中
        public void JoinCallBack(string userName)
        {
            NotificationLog("User (" + userName + ") join at " + DateTime.Now.ToString());
            SetUserLoginUI(userName);
        }
        //群聊
        public void ReceiveGroupChatMsgCallback(string sender, string message)
        {
            string messageEx = sender + " " + DateTime.Now.ToLongTimeString() + " :" + message + Environment.NewLine;
            SetUserChatMsg(messageEx, ChatRoomMsg);
        }
        //单聊
        public void ReceiveSingleChatMsgCallback(string sender, string message)
        {
            SetUserChatMsg(sender + " say to YOU @" + DateTime.Now.ToLongTimeString() + " :" + message + Environment.NewLine, ChatRoomMsg);
        }
        //离开
        public void LeaveMeetingCallBack(string userName)
        {
            NotificationLog("User (" + userName + ") leave at " + DateTime.Now.ToString());
            ResetUserLoginUI(userName);
        }
        #endregion

        #region Set UI State
        private void NotificationLog(string text)
        {
            NotificationBox.Items.Add(text);
            CommonUntil.SendMessage(NotificationBox.Handle, WM_VSCROLL, SB_BOTTOM, new IntPtr(0));
        }

        private void SetUserChatMsg(string text,TRichTextBox chatMsgContainer)
        {
            CommonUntil.AddContent(text, chatMsgContainer);
            CommonUntil.SendMessage(chatMsgContainer.Handle, WM_VSCROLL, SB_BOTTOM, new IntPtr(0));
        }

        private void SetUserLoginUI(string text)
        {
            ListViewItem lvi = new ListViewItem();
            lvi.SubItems.Add(text);
            lvi.ImageIndex = 0;
            if(nickName.Equals(text))
                lvi.BackColor = Color.Wheat;  // specify yourself with wheat color
            UserListBox.Items.Add(lvi);
        }
        private void ResetUserLoginUI(string text)
        {
            ListViewItem lvi = UserListBox.FindItemWithText(text);
            if (lvi != null) UserListBox.Items.Remove(lvi);
        }

        private void ChatWithWho(string toWho, string message, bool flag)
        {
            try
            {
                if (flag)  // say to all
                    chatClient.GroupChat(message);
                else  // say to someone
                    chatClient.SingleChat(toWho, message);
                PrivateMessage.Text = string.Empty;
            }
            catch
            {
                ExitChatRoom();
            }
        }
        #endregion

        #region Event

        //群聊按钮事件
        private void BtnToAll_Click(object sender, EventArgs e)
        {
            ChatWithWho(string.Empty,PrivateMessage.Text,true);
            base.Invalidate(true);
        }
        //单聊按钮事件
        private void BtnToOne_Click(object sender, EventArgs e)
        {
            try
            {
                ListView.SelectedListViewItemCollection collection = UserListBox.SelectedItems;
                string name = collection[0].SubItems[1].Text;
                SetUserChatMsg(Environment.NewLine + "you say to " + name + " @" + DateTime.Now + " :" + PrivateMessage.Text + "\r\n",ChatRoomMsg);
                ChatWithWho(name, PrivateMessage.Text, false);
                base.Invalidate(true);
            }
            catch
            {
                MessageBox.Show("pls select  a person to chat.");
                return;
            }
        }
        //窗体关闭事件,销毁对象
        private void MainFrm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ExitChatRoom();
        }
        //表情框弹出事件
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            emotionFlag = !emotionFlag;
            panImg.Visible = emotionFlag;
        }
        //窗体加载事件
        private void MainFrm_Load(object sender, EventArgs e)
        {
            CommonUntil.LoadingEmotion(emotionFlag,panImg,PrivateMessage);
        }
        #endregion

        private void UserListBox_Leave(object sender, EventArgs e)
        {
            object syncObj = new object();

            string text = UserListBox.SelectedItems[0].SubItems[1].Text;
            ListViewItem lviCurrentSelected =  UserListBox.SelectedItems[0];

            //还原之前选中的对象
            ListView.ListViewItemCollection lviCollection = UserListBox.Items;

            UserListBox.Invoke(new Action(() =>
            {
                Parallel.For(0, lviCollection.Count, new Action<int>(i =>
                {
                        lock (syncObj)
                        {
                            ListViewItem lvi = lviCollection[i];
                            if (lvi.BackColor == Color.Gray)
                                lvi.BackColor = Color.Transparent;
                        }
                }));
            }));
           

            if (!text.Equals(nickName))
                lviCurrentSelected.BackColor = Color.Gray;
        }
    }
}
