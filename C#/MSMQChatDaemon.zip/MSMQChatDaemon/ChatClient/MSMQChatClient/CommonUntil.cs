﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using Trestan;

namespace MSMQChatClient
{
    public class CommonUntil
    {
        public CommonUntil() { }

        public static void LoadingEmotion(bool emotionFlag, Panel panImg, TextBox rSendContent)
        {
            PictureBox[,] picList = new PictureBox[5, 10];
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    int emotionSequenceCount = i * 10 + j;
                    picList[i, j] = new PictureBox();
                    picList[i, j].Height = picList[i, j].Width = 24;
                    picList[i, j].Image = Image.FromFile(".\\Face2\\" + emotionSequenceCount + ".gif");
                    picList[i, j].Top = i * 24;
                    picList[i, j].Left = j * 24;
                    picList[i, j].Tag = "#(" + emotionSequenceCount + ")#";
                    picList[i, j].Parent = panImg;
                    picList[i, j].Click += new EventHandler((sender, e) =>
                    {
                        rSendContent.AppendText("#(" + emotionSequenceCount + ")#");
                        emotionFlag = false;
                        panImg.Visible = emotionFlag;
                    });
                    panImg.Controls.Add(picList[i, j]);
                }
            }
        }

        public static void AddContent(string text, TRichTextBox rAllContent)
        {
            //解析发送的内容，实现表情匹配。
            string sendText = "#(S)#" + text + "#(E)#";
            Regex regex = new Regex(@"(#\([0-9|S|E]+\)#).*?(?=#\([0-9|S|E]+\)#)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            Regex regexImage = new Regex(@"(#\([0-9|S|E]+\)#)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            Regex regexPlainText = new Regex(@"(?<=(#\([0-9|S|E]+\)#)).*", RegexOptions.Singleline | RegexOptions.IgnoreCase);
            MatchCollection matches = regex.Matches(sendText);
            foreach (Match match in matches)
            {
                string matchedValue = match.Value;

                Match matchImage = regexImage.Match(matchedValue);
                Match matchPlainText = regexPlainText.Match(matchedValue);

                if (!String.IsNullOrEmpty(matchImage.Value))
                {
                    if (!matchImage.Value.Contains("#(S)#"))
                    {
                        //rAllContent.InsertImageUseImageOle(".\\Face2\\" + matchImage.Value.Replace("#(", string.Empty).Replace(")#", string.Empty) + ".gif");
                        Image myImage = Image.FromFile(".\\Face2\\" + matchImage.Value.Replace("#(", string.Empty).Replace(")#", string.Empty) + ".gif");
                        PictureBox pic = new PictureBox();
                        pic.Image = myImage;
                        pic.Size = myImage.Size;
                        rAllContent.AddControl(pic);
                    }
                    rAllContent.AppendText(matchPlainText.Value);
                }
            }
        }

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int msg, int wParam, IntPtr lParam);
       

    }
}
