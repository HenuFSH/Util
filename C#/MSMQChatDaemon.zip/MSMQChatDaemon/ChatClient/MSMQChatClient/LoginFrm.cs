﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace MSMQChatClient
{

    public delegate void UserLoginDelegate(string nickName);

    public partial class LoginFrm : Form
    {
        public LoginFrm()
        {
            InitializeComponent();
        }

        public event UserLoginDelegate UserLoginEvent;

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string nickName = txtNickName.Text;

            if (String.IsNullOrEmpty(nickName))
            {
                lblStatus.Invoke(new Action(() => { lblStatus.Text = "Please input user nick name!!"; }));
                return;
            }

            if (UserLoginEvent != null)
                UserLoginEvent(nickName);
        }

        public void ShowStatus(string log)
        {
            lblStatus.Invoke(new Action(() => { lblStatus.Text = log; }));
        }
    }
}
