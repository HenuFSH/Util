﻿using Trestan;
namespace MSMQChatClient
{
    partial class MainFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myStatus = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.gpChatRoom = new System.Windows.Forms.GroupBox();
            this.ChatRoomMsg = new TRichTextBox();
            this.gpUserList = new System.Windows.Forms.GroupBox();
            this.UserListBox = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.myImgList = new System.Windows.Forms.ImageList(this.components);
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.gpPrivateSession = new System.Windows.Forms.GroupBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.panImg = new System.Windows.Forms.Panel();
            this.PrivateMessage = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.BtnToOne = new System.Windows.Forms.Button();
            this.BtnToAll = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gpNotificationArea = new System.Windows.Forms.GroupBox();
            this.NotificationBox = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.myStatus.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.gpChatRoom.SuspendLayout();
            this.gpUserList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.gpPrivateSession.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.gpNotificationArea.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(583, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // myStatus
            // 
            this.myStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
            this.myStatus.Location = new System.Drawing.Point(0, 430);
            this.myStatus.Name = "myStatus";
            this.myStatus.Size = new System.Drawing.Size(583, 22);
            this.myStatus.TabIndex = 4;
            // 
            // statusLabel
            // 
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(116, 17);
            this.statusLabel.Text = "User *** has logged in";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.splitContainer1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(583, 202);
            this.panel1.TabIndex = 5;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.gpChatRoom);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gpUserList);
            this.splitContainer1.Size = new System.Drawing.Size(583, 202);
            this.splitContainer1.SplitterDistance = 413;
            this.splitContainer1.TabIndex = 0;
            // 
            // gpChatRoom
            // 
            this.gpChatRoom.Controls.Add(this.ChatRoomMsg);
            this.gpChatRoom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gpChatRoom.Location = new System.Drawing.Point(0, 0);
            this.gpChatRoom.Name = "gpChatRoom";
            this.gpChatRoom.Size = new System.Drawing.Size(413, 202);
            this.gpChatRoom.TabIndex = 0;
            this.gpChatRoom.TabStop = false;
            this.gpChatRoom.Text = "Chat Room";
            // 
            // ChatRoomMsg
            // 
            this.ChatRoomMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChatRoomMsg.Font = new System.Drawing.Font("SimHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ChatRoomMsg.Location = new System.Drawing.Point(3, 16);
            this.ChatRoomMsg.Name = "ChatRoomMsg";
            this.ChatRoomMsg.Size = new System.Drawing.Size(407, 183);
            this.ChatRoomMsg.TabIndex = 0;
            this.ChatRoomMsg.Text = "";
            // 
            // gpUserList
            // 
            this.gpUserList.Controls.Add(this.UserListBox);
            this.gpUserList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gpUserList.Location = new System.Drawing.Point(0, 0);
            this.gpUserList.Name = "gpUserList";
            this.gpUserList.Size = new System.Drawing.Size(166, 202);
            this.gpUserList.TabIndex = 0;
            this.gpUserList.TabStop = false;
            this.gpUserList.Text = "User List";
            // 
            // UserListBox
            // 
            this.UserListBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.UserListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UserListBox.FullRowSelect = true;
            this.UserListBox.GridLines = true;
            this.UserListBox.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.UserListBox.LargeImageList = this.myImgList;
            this.UserListBox.Location = new System.Drawing.Point(3, 16);
            this.UserListBox.Name = "UserListBox";
            this.UserListBox.Size = new System.Drawing.Size(160, 183);
            this.UserListBox.SmallImageList = this.myImgList;
            this.UserListBox.TabIndex = 0;
            this.UserListBox.UseCompatibleStateImageBehavior = false;
            this.UserListBox.View = System.Windows.Forms.View.Details;
            this.UserListBox.Leave += new System.EventHandler(this.UserListBox_Leave);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 24;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Width = 132;
            // 
            // myImgList
            // 
            this.myImgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("myImgList.ImageStream")));
            this.myImgList.TransparentColor = System.Drawing.Color.Transparent;
            this.myImgList.Images.SetKeyName(0, "tux.png");
            this.myImgList.Images.SetKeyName(1, "1-120H31H202.png");
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 24);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Size = new System.Drawing.Size(583, 406);
            this.splitContainer2.SplitterDistance = 202;
            this.splitContainer2.TabIndex = 6;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.gpPrivateSession);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.gpNotificationArea);
            this.splitContainer3.Size = new System.Drawing.Size(583, 200);
            this.splitContainer3.SplitterDistance = 412;
            this.splitContainer3.TabIndex = 0;
            // 
            // gpPrivateSession
            // 
            this.gpPrivateSession.Controls.Add(this.splitContainer4);
            this.gpPrivateSession.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gpPrivateSession.Location = new System.Drawing.Point(0, 0);
            this.gpPrivateSession.Name = "gpPrivateSession";
            this.gpPrivateSession.Size = new System.Drawing.Size(412, 200);
            this.gpPrivateSession.TabIndex = 0;
            this.gpPrivateSession.TabStop = false;
            this.gpPrivateSession.Text = "Private session";
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(3, 16);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.panImg);
            this.splitContainer4.Panel1.Controls.Add(this.PrivateMessage);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.flowLayoutPanel1);
            this.splitContainer4.Size = new System.Drawing.Size(406, 181);
            this.splitContainer4.SplitterDistance = 147;
            this.splitContainer4.TabIndex = 0;
            // 
            // panImg
            // 
            this.panImg.BackColor = System.Drawing.Color.White;
            this.panImg.Location = new System.Drawing.Point(163, 18);
            this.panImg.Name = "panImg";
            this.panImg.Size = new System.Drawing.Size(240, 130);
            this.panImg.TabIndex = 2;
            this.panImg.Visible = false;
            // 
            // PrivateMessage
            // 
            this.PrivateMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PrivateMessage.Location = new System.Drawing.Point(0, 0);
            this.PrivateMessage.Multiline = true;
            this.PrivateMessage.Name = "PrivateMessage";
            this.PrivateMessage.Size = new System.Drawing.Size(406, 147);
            this.PrivateMessage.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.BtnToOne);
            this.flowLayoutPanel1.Controls.Add(this.BtnToAll);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox1);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(406, 30);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // BtnToOne
            // 
            this.BtnToOne.Location = new System.Drawing.Point(322, 3);
            this.BtnToOne.Name = "BtnToOne";
            this.BtnToOne.Size = new System.Drawing.Size(81, 23);
            this.BtnToOne.TabIndex = 0;
            this.BtnToOne.Text = "Send To &One";
            this.BtnToOne.UseVisualStyleBackColor = true;
            this.BtnToOne.Click += new System.EventHandler(this.BtnToOne_Click);
            // 
            // BtnToAll
            // 
            this.BtnToAll.Location = new System.Drawing.Point(241, 3);
            this.BtnToAll.Name = "BtnToAll";
            this.BtnToAll.Size = new System.Drawing.Size(75, 23);
            this.BtnToAll.TabIndex = 1;
            this.BtnToAll.Text = "Send To &All";
            this.BtnToAll.UseVisualStyleBackColor = true;
            this.BtnToAll.Click += new System.EventHandler(this.BtnToAll_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MSMQChatClient.ChatClientRes.Laugh;
            this.pictureBox1.Location = new System.Drawing.Point(213, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 23);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // gpNotificationArea
            // 
            this.gpNotificationArea.Controls.Add(this.NotificationBox);
            this.gpNotificationArea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gpNotificationArea.Location = new System.Drawing.Point(0, 0);
            this.gpNotificationArea.Name = "gpNotificationArea";
            this.gpNotificationArea.Size = new System.Drawing.Size(167, 200);
            this.gpNotificationArea.TabIndex = 0;
            this.gpNotificationArea.TabStop = false;
            this.gpNotificationArea.Text = "Notification Area";
            // 
            // NotificationBox
            // 
            this.NotificationBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NotificationBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NotificationBox.FormattingEnabled = true;
            this.NotificationBox.HorizontalScrollbar = true;
            this.NotificationBox.Location = new System.Drawing.Point(3, 16);
            this.NotificationBox.Name = "NotificationBox";
            this.NotificationBox.Size = new System.Drawing.Size(161, 181);
            this.NotificationBox.TabIndex = 1;
            // 
            // MainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 452);
            this.Controls.Add(this.splitContainer2);
            this.Controls.Add(this.myStatus);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainFrm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainFrm_FormClosing);
            this.Load += new System.EventHandler(this.MainFrm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.myStatus.ResumeLayout(false);
            this.myStatus.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.gpChatRoom.ResumeLayout(false);
            this.gpUserList.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.gpPrivateSession.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.gpNotificationArea.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip myStatus;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox gpChatRoom;
        private System.Windows.Forms.GroupBox gpUserList;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.GroupBox gpPrivateSession;
        private System.Windows.Forms.GroupBox gpNotificationArea;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ListBox NotificationBox;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.TextBox PrivateMessage;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button BtnToOne;
        private System.Windows.Forms.Button BtnToAll;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.ListView UserListBox;
        private System.Windows.Forms.ImageList myImgList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panImg;
        private TRichTextBox ChatRoomMsg;
    }
}